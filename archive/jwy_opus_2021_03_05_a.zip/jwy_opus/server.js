var express = require('express');
var app = express();
var path = require('path');
var timesyncServer = require('timesync/server');
var server = require('http').createServer(app);
io = require('socket.io').listen(server);
var FileReader = require('filereader');
var fileReader = new FileReader();
const fs = require('fs');

const PORT = process.env.PORT || 5000

app.use(express.static(path.join(__dirname, '/public')));

app.get('/', function(req, res) {
  res.sendFile(path.join(__dirname, '/public/index.html'));
});

server.listen(PORT, () => console.log(`Listening on ${ PORT }`));

// handle timesync requests
app.use('/timesync', timesyncServer.requestHandler);

var currentWorks = [];
var currentWorksIX = 0;

//Main Server socket.io
io.on('connection', function(socket) {
  //Request for new piece from splash page
  socket.on('mkNewPiece', function(data) {
    var newPieceType = data.pieceType;
    var newPieceName = data.pieceName;
    var newPieceData = data.pieceData;
    //Generate Piece ID:
    //// Timestamp
    var dt = new Date();
    var year = dt.getFullYear();
    var month = dt.getMonth() + 1;
    var day = dt.getDate();
    var hour = dt.getHours();
    var min = dt.getMinutes();
    var timestamp = year + "_" + month + "_" + day + "_" + hour + "_" + min;
    var newPieceID = currentWorksIX + "-" + timestamp;
    var newPieceArr = [newPieceID, newPieceType, newPieceName, newPieceData];
    //Populate currentWorks array here in server
    currentWorks.push(newPieceArr);
    currentWorksIX++;
    socket.broadcast.emit('newPieceBroadcast', {
      newPieceArr: newPieceArr
    });
    socket.emit('newPieceBroadcast', {
      newPieceArr: newPieceArr
    });
  });
  //Request for load piece from splash page
  // socket.on('loadPiece', function(data) {
  //   var pieceType = data.pieceType;
  //   var pieceName = data.pieceName;
  //   switch (pieceType) {
  //     case 'sf002':
  //       //joining path of directory
  //       const directoryPath = path.join(__dirname, 'public/savedScoreData/sf002');
  //       //passsing directoryPath and callback function
  //       fs.readdir(directoryPath, function(err, files) {
  //         console.log(files);
  //         //handling error
  //         if (err) {
  //           return console.log('Unable to scan directory: ' + err);
  //         }
  //         //Send list of files in directory to Splash page
  //         socket.broadcast.emit('loadPieceBroadcast', {
  //           availableScoreData: files
  //         });
  //         socket.emit('loadPieceBroadcast', {
  //           availableScoreData: files
  //         });
  //
  //       });
  //       break;
  //   }
  // });
});
